from __future__ import annotations

"""
Runtime_Config

Single place to load framework-level runtime configs from the repo-level /configs folder.

Why:
- Keeps "constants" out of code (you said YAML or we riot).
- Avoids circular imports between orchestrator / prompt compiler.
- Provides safe defaults when configs are missing.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

_CACHE: Dict[str, Dict[str, Any]] = {}


def _find_configs_dir(start: Optional[Path] = None) -> Optional[Path]:
    """
    Heuristic search for a 'configs' directory.
    Search order:
      1) start (or CWD) and its parents
      2) this file's parents
    """
    roots = []
    roots.append((start or Path.cwd()).resolve())
    roots.append(Path(__file__).resolve())

    for root in roots:
        for p in [root] + list(root.parents):
            c = p / "configs"
            if c.exists() and c.is_dir():
                return c
    return None


def _load_yaml(path: Path) -> Dict[str, Any]:
    try:
        import yaml  # type: ignore
    except Exception:
        # YAML is optional at install time; default configs will be used.
        return {}
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def load_config_yaml(filename: str) -> Dict[str, Any]:
    """
    Load configs/<filename>.yaml into a dict (cached).
    If missing or YAML isn't installed, returns {}.
    """
    key = filename.strip()
    if key in _CACHE:
        return _CACHE[key]

    cfg_dir = _find_configs_dir()
    if not cfg_dir:
        _CACHE[key] = {}
        return _CACHE[key]

    # allow passing either "foo" or "foo.yaml"
    fn = key if key.lower().endswith((".yaml", ".yml")) else f"{key}.yaml"
    path = cfg_dir / fn
    if not path.exists():
        _CACHE[key] = {}
        return _CACHE[key]

    _CACHE[key] = _load_yaml(path)
    return _CACHE[key]


def get_str(d: Dict[str, Any], k: str, default: str) -> str:
    v = d.get(k, default)
    return default if v is None else str(v)


def get_int(d: Dict[str, Any], k: str, default: int) -> int:
    v = d.get(k, default)
    try:
        return int(v)
    except Exception:
        return default


def get_bool(d: Dict[str, Any], k: str, default: bool) -> bool:
    v = d.get(k, default)
    if isinstance(v, bool):
        return v
    if isinstance(v, str):
        return v.strip().lower() in {"1", "true", "yes", "y", "on"}
    return default


def get_list_str(d: Dict[str, Any], k: str, default: list[str]) -> list[str]:
    v = d.get(k, None)
    if v is None:
        return list(default)
    if isinstance(v, list):
        return [str(x) for x in v if x is not None]
    return list(default)
