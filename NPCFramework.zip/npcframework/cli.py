from __future__ import annotations

import argparse
from pathlib import Path
import sys

# Public API only
from npcframework.api import Engine, Session
from npcframework.core.NPC_Validator import validate_npc_dir
from npcframework.npcframework_types import EngineConfig

engine = Engine(EngineConfig(backend="llamacpp"))  # or mock, etc.


def cmd_validate(args: argparse.Namespace) -> int:
    npc_dir = Path(args.npc_dir)
    ok, err = validate_npc_dir(str(npc_dir))
    if ok:
        print(f"OK: {npc_dir}")
        return 0
    print(f"INVALID: {npc_dir}")
    if err:
        print(err)
    return 2


def cmd_run(args: argparse.Namespace) -> int:
    engine = Engine()  # default engine config (you already support this)
    session = Session(
        npc_dir=args.npc_dir,
        engine=engine,
    )

    result = session.run_turn(args.user_input)

    if result.error:
        print("ERROR:", result.error)
        return 1

    print(f"{result.npc_name}> {result.assistant_reply}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="npcframework",
        description="NPCFramework CLI",
    )

    sub = parser.add_subparsers(dest="cmd", required=True)

    # validate
    p_validate = sub.add_parser("validate", help="Validate an NPC directory")
    p_validate.add_argument("npc_dir")
    p_validate.set_defaults(func=cmd_validate)

    # run
    p_run = sub.add_parser("run", help="Run a single NPC turn")
    p_run.add_argument("npc_dir")
    p_run.add_argument("user_input")
    p_run.set_defaults(func=cmd_run)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
