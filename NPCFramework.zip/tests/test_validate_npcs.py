from pathlib import Path

def test_validate_kevin(validator):
    npc_dir = Path("npc/kevin.npc")
    ok, err = validator(str(npc_dir))
    assert ok, err

def test_validate_anna(validator):
    npc_dir = Path("npc/anna.npc")
    ok, err = validator(str(npc_dir))
    assert ok, err
