from pathlib import Path
from npcframework.core.Runtime_Inference_LlamaCPP import build_engine, RuntimeConfig, TurnRequest, run_turn

def test_tool_call_executes():
    cfg = RuntimeConfig(channel="test", environment_id="test", environment_name="test", debug_print_messages=False)
    engine = build_engine(cfg)

    # Your mock model must emit /tool_call for this to work.
    # If it doesn't, adjust your Mock backend to produce a tool call when prompted.
    user_input = "Use tool add with a=2 and b=3, then tell me the result."

    result = run_turn(
        req=TurnRequest(npc_dir=str(Path("npc/kevin.npc")), user_input=user_input),
        cfg=cfg,
        engine=engine,
    )

    assert result.error is None
    # If you store tool traces, assert they contain add
    # assert any(tc.tool == "add" for tc in result.trace.tool_calls)
