import sqlite3
from pathlib import Path
from npcframework.core.Runtime_Inference_Mock import build_engine, RuntimeConfig, TurnRequest, run_turn

def test_db_writes_event(tmp_path):
    # copy npc to tmp so tests don't mutate your real npc.db
    import shutil
    src = Path("npc/kevin.npc")
    dst = tmp_path / "kevin.npc"
    shutil.copytree(src, dst)

    cfg = RuntimeConfig(channel="test", environment_id="test", environment_name="test", debug_print_messages=False)
    engine = build_engine(cfg)

    result = run_turn(
        req=TurnRequest(npc_dir=str(dst), user_input="Hello"),
        cfg=cfg,
        engine=engine,
    )
    assert result.error is None

    db_path = dst / "npc.db"
    assert db_path.exists()

    con = sqlite3.connect(db_path)
    cur = con.cursor()
    # Adjust table name to whatever you actually use (event_log, events, etc.)
    cur.execute("SELECT COUNT(*) FROM event_log")
    (count,) = cur.fetchone()
    assert count > 0
    con.close()
