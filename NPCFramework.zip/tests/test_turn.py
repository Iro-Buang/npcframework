from pathlib import Path
from npcframework.core.Runtime_Inference_LlamaCPP import build_engine, RuntimeConfig, TurnRequest, run_turn

def test_one_turn_mock():
    cfg = RuntimeConfig(channel="test", environment_id="test", environment_name="test", debug_print_messages=False)
    engine = build_engine(cfg)
    result = run_turn(
        req=TurnRequest(npc_dir=str(Path("npc/kevin.npc")), user_input="Hello"),
        cfg=cfg,
        engine=engine,
    )
    assert result.error is None
    assert result.assistant_reply is not None
